//
//  ViewController.swift
//  MNCAppsSDKExample
//
//  Created by Victor Toya on 22/03/21.
//  Copyright © 2021 MNC Innovation Center. All rights reserved.
//

import UIKit
import MNCAppsSDK

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func onClickButton(_ sender: Any) {
        
        let request = MNCAppsRequest()
        request.setUserID("irKmyJJGGlNjMt7Kpg3xYlRT6dn1")
        request.setBundleid("an.android.app")
        request.setLanguage("en")
        request.setIntervals(1)
        
        let screen = MNCAppsScreen(request: request)
        screen.setDarkMode(false)
        screen.modalPresentationStyle = .fullScreen
        self.present(screen, animated: false, completion: nil)
    }
    
}

